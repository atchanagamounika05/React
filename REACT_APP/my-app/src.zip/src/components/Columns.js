import React from "react";

function Columns() {
  /* const items = [1, 2, 3, 4, 5]; */
  return (
    <React.Fragment>
      {/* {items.map(item => (
        <React.Fragment key={item}><h1>title</h1></React.Fragment>)
      )} */}

      <td>Name</td>
      <td>Mounika</td>
    </React.Fragment>
  );
}

export default Columns;

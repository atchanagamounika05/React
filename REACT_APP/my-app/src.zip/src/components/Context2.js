import React, { Component } from "react";
import Context3 from "./Context3";
export class Context2 extends Component {
  render() {
    return (
      <div>
        Component 2
        <Context3 />
      </div>
    );
  }
}

export default Context2;

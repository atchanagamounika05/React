import React from 'react'

export default function FragmentDemo() {
  return (
    //<React.Fragment>
    <>
    <h1>
      FragmentDemo
    </h1>
    <p>This is react fragments demo</p>
    </>
    //</React.Fragment>
  )
}
